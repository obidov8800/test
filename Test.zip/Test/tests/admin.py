from django.contrib import admin
from .models import Subject, Question, Answer

admin.site.register(Subject)
admin.site.register(Question)
admin.site.register(Answer)

# Register your models here.
